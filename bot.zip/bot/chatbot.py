import streamlit as st
import pandas as pd
import gensql
from database_connector import execute_sql_query
import json
import streamlit.components.v1 as components  # Import Streamlit components

st.title("Chatbot Application")
st.write("Ask any question and get an answer:")

# Input for user question
user_input = st.text_input("You:")

if user_input:
    # Generate SQL query from user input
    sql_query = gensql.generate_new_trial(user_input)
    st.write("Generated SQL Query:")
    st.code(sql_query, language='sql')
    
    # Execute the SQL query
    try:
        column_names, results = execute_sql_query(sql_query)
        
        # Display the results
        if results:
            st.write("Query Results:")
            df = pd.DataFrame(results, columns=column_names)
            
            # Remove duplicate rows
            df_unique = df.drop_duplicates()
            
            st.table(df_unique)
            
            # Convert DataFrame to JSON
            results_json = df_unique.to_json(orient='records')
            
            # Save JSON to a file
            with open("query_results.json", "w") as f:
                f.write(results_json)
            
            # Embed dendro.html in Streamlit
            with open("dendro.html", "r") as f:
                html_content = f.read()
            
            # Replace placeholder with the JSON data
            html_content = html_content.replace("var data =[];", f"var data ={results_json};")
            
            # Render the HTML
            components.html(html_content, height=500)
            
        else:
            st.write("No results found.")
    except Exception as e:
        st.write(f"An error occurred: {e}")
